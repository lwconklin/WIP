#include <iostream>
#include "mmf.h"



using namespace std;


int main(int argc, char *argv[])
{
	string inName;
	inName = "C:\\_testData\\myTestData";
    mmf MMFile;
	MMFile.MapFile(inName);
	MMFile.StripMapFile();
	MMFile.CloseMapFile();


   
    return 0; // never reached
}
