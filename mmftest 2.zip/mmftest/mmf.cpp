#include "mmf.h"

mmf::mmf(void)
{
	mmFile = NULL;
	fileLength=0;
	fileSizeHigh=0;
    fileIn = NULL;
	pBuf = NULL;
	
}

mmf::~mmf(void)
{
}

void
mmf::MapFile(string source)
{
	fileName = source;
    if ((fileIn = CreateFile(fileName.c_str(), GENERIC_READ,0, 0, OPEN_EXISTING, 0, 0)) == INVALID_HANDLE_VALUE) {
        cerr << "Error opening source: " << GetLastError() << endl;
        exit(1);
    }

	// Get the size of the file we are mapping
	fileLength = GetFileSize(fileIn, &fileSizeHigh);
	if (fileLength == 0xFFFFFFFF) {
		cerr << "There was an error calling GetFileSize. " << source << endl;
		exit(1);
	}
 
	if (fileSizeHigh){
		cerr << source << " is greater than 4GB in size." << endl;
		exit(1);
    }

	//Fail if file is 0 length in size
	if (fileSizeHigh == 0 && fileLength == 0){
		cerr << source << " is 0 length in size." << endl;
		exit(1);
	}

	mmFile = CreateFileMapping(fileIn,NULL, PAGE_READONLY, 0,fileLength,NULL);

	if (mmFile == NULL){
		cerr << "There was an error calling CreateFileMapping. " << source << endl;
		CloseMapFile();
		exit(1);
    }

	pBuf =  (LPTSTR) MapViewOfFile(mmFile, FILE_MAP_READ,0,0,fileLength);           
    if (pBuf == NULL) { 
		cerr << "Could not map view of " << source << endl;
		CloseMapFile();
		exit(1);
    }
}

void
mmf::CloseMapFile()
{
	CloseHandle(fileIn);
}

void
mmf::StripMapFile()
{
	StripFileInfo.fileName = fileName;
	StripFileInfo.fileSize = fileLength;
	StripFileInfo.streamCount = numberOfStrips;

	long bytesPerStrip = fileLength/numberOfStrips;
	int remainder = fileLength % numberOfStrips;

	StripFileInfo.stripStartPointer1 = pBuf;
	StripFileInfo.stripSize1 = bytesPerStrip;

	StripFileInfo.stripStartPointer2 = pBuf + bytesPerStrip;
	StripFileInfo.stripSize2 = bytesPerStrip;
	
	StripFileInfo.stripStartPointer3 = pBuf + bytesPerStrip + bytesPerStrip;
	StripFileInfo.stripSize3 = bytesPerStrip + remainder;
	
}

stripFileInfo
mmf::GetStripFileInformation()
{
	return StripFileInfo;
}
