#ifndef MemoryMapFile_H
#define MemoryMapFile_H

#include <windows.h>
#include <winioctl.h>

//Define taken from the Windows 2000 Beta platform SDK. Definition differs on xp
#ifndef FSCTL_SET_SPARSE
#define FSCTL_SET_SPARSE   CTL_CODE(FILE_DEVICE_FILE_SYSTEM, 49, METHOD_BUFFERED, FILE_WRITE_DATA)
#endif
#include<string>
#include <iostream>

using namespace std;

const int numberOfStrips = 3;


struct stripFileInfo {
	int streamCount;
    long fileSize;
	string fileName;
	int stripSize1;		
	char * stripStartPointer1;
	int stripSize2;
	char * stripStartPointer2;
	int stripSize3;
	char * stripStartPointer3;
};


class mmf
{
public:
	mmf(void);
public:
	virtual ~mmf(void);
	void MapFile(string);
	void CloseMapFile();
	void StripMapFile();
	stripFileInfo GetStripFileInformation();



private:
	mmf(const mmf& rhs);			// copy constructor
	mmf& operator = (const mmf& rhs);	// assignment operator
	const mmf* operator&() const;
	HANDLE mmFile; 
	DWORD fileLength;
	DWORD fileSizeHigh;
    HANDLE fileIn;
	char *pBuf;
	stripFileInfo StripFileInfo;
	string fileName;
};

#endif
