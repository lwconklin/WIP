#include <iostream>
#include <windows.h>
#include <winioctl.h>

//Define taken from the Windows 2000 Beta platform SDK. Definition differs on xp
#ifndef FSCTL_SET_SPARSE
#define FSCTL_SET_SPARSE   CTL_CODE(FILE_DEVICE_FILE_SYSTEM, 49, METHOD_BUFFERED, FILE_WRITE_DATA)
#endif



using namespace std;


const int BUF_SIZE = 1024;

int main1(int argc, char *argv[])
{
	DWORD fileLength=0;
	DWORD fileSizeHigh=0;
    HANDLE fileIn = NULL;
	HANDLE mmf = NULL;
    char buf[BUF_SIZE];
    char inName[MAX_PATH];
    DWORD nread,nwrote;


	strcpy_s(inName,"C:\\_testData\\myTestData");
    

    if ((fileIn = CreateFile(inName, GENERIC_READ,0, 0, OPEN_EXISTING, 0, 0)) == INVALID_HANDLE_VALUE) {
        cerr << "Error opening source: " <<
                 GetLastError() << endl;
        exit(1);
    }

	// Get the size of the file we are mapping
	fileLength = GetFileSize(fileIn, &fileSizeHigh);
	if (fileLength == 0xFFFFFFFF) {
		//There was an error calling GetFileSize
	}
    //Fail if file is greater than 4GB in size
	if (fileSizeHigh){
    }

	//Fail if file is 0 length in size
	if (fileSizeHigh == 0 && fileLength == 0){
	}

	mmf = CreateFileMapping(fileIn,NULL, PAGE_READONLY, 0,fileLength,NULL);

	if (mmf == NULL){
    }

char *pBuf;


pBuf =  (LPTSTR) MapViewOfFile(mmf, FILE_MAP_READ,0,0,BUF_SIZE);           


   if (pBuf == NULL) 
   { 
      printf("Could not map view of file (%d).\n",GetLastError()); 
      return 2;
   }


 //  for(long i= 0; i <= 20; i++) {
//	   cout << pBuf[i] << endl;
 //  }
	  memset (buf,'\0',BUF_SIZE);

	  memcpy (buf,pBuf,10);
	  printf ("%s",buf);
	  memcpy (buf,pBuf+10,10);
	  printf ("%s\n",buf);
	



    CloseHandle(fileIn);
 

    exit(0);
    return 0; // never reached
}
